V23_4 full-release rebuild from uploaded repository bundle and source corpus. Standalone zip readiness required. Not a patch.
